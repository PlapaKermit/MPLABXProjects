unsigned char ADC_read(int channel);
void DAC_write(unsigned char value);