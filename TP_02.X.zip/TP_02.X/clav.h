far unsigned char Clavier @0x180000;
unsigned char mem_touche;
unsigned char high_priority interrupt get_val_clav ();