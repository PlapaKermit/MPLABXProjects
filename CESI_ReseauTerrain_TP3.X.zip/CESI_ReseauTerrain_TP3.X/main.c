/*
 * File:   main.c
 * Author: sduval
 *
 * 6 d�cembre 2020, 17:28
 */

#include "main.h"
#include "afficheur.h"
#include "spi.h"
#include "eep_spi.h"
#include "i2c.h"
#include "can_spi.h"

uint8_t u8Test = 0;

void initialisation_des_ports()
{
// D�sactivation du bus externe
    MEMCON=0xA0;    //ebdis=1 bus d�sactiv� (sauf en cas d'acc�s externe)

// D�sactivation des fonctions analogiques
    ANCON0=0x03; // ecran tactile en analogique X et Y
    ANCON1=0x08; // AN11 = entr�e analogique V_pot
    ANCON2=0x00;


// Valeur initiale des ports en sortie
    LED_R=0;
    LED_G=0;
    LED_B=0;

// D�finition du sens des ports
    TRISAbits.TRISA2=0; //LED1
    TRISAbits.TRISA3=0; //LED2
    TRISAbits.TRISA4=0; //LED3
    TRISAbits.TRISA5=0; //LED4
    TRISCbits.TRISC2=0; //LED_R en sortie
    TRISCbits.TRISC1=0; //LED_G en sortie
    TRISGbits.TRISG0=0; //LED_B en sortie
    TRISCbits.TRISC3=1;
    TRISCbits.TRISC4=1;

// Mise en place des pull up
    INTCON2bits.RBPU=0; // Pull up PORTB activ�
    PADCFG1bits.REPU=1; // Pull up PORTE activ�

}

void main(void)
{
    initialisation_des_ports();
    initialisation_afficheur();

    SPI_Initialize();
    EEP_SPI_Initialize();
    
    CAN_SPI_Configure();

    I2C_Initialize();

    clear_text();
    clear_graphics();

    goto_lico(0,0);
    draw_string((unsigned char *)"Hello");


    u8Test = CAN_SPI_ReadOperationMode();
    CAN_SPI_SetNormalOperationMode();
    u8Test = CAN_SPI_ReadOperationMode();

    while(1)
    {

    }
}
